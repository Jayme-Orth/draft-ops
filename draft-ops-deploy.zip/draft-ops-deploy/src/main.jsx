import React from 'react';
import ReactDOM from 'react-dom/client';
import DraftApp from './DraftApp.jsx';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <DraftApp />
  </React.StrictMode>
);
